//! Read only: compare hand cues with the saved grid, and optionally analyse
//! the source audio into the caller's diagnostic directory. Never writes cues.
use std::path::Path;
fn main()->Result<(),Box<dyn std::error::Error>> {
    let args:Vec<_>=std::env::args().collect();
    let input=Path::new(args.get(1).ok_or("reference JSON required")?);
    let out=Path::new(args.get(2).ok_or("output directory required")?);
    std::fs::create_dir_all(out)?;
    let mut refs:Vec<serde_json::Value>=serde_json::from_slice(&std::fs::read(input)?)?;
    let db=rbl_db::Library::open_installed_read_only()?;
    let (library,_)=rbl_index::load(&db)?;
    for item in &mut refs {
        let id=item["id"].as_str().ok_or("missing ID")?.to_owned();
        let Some(row)=library.row_of(&id) else {continue;};
        let dat=rbl_anlz::resolve(&db.location().share_root,library.analysis_path.get(row as usize));
        let anlz=rbl_anlz::Anlz::read(&dat)?;
        let offset=i64::from(anlz.grid_offset().unwrap_or(0));
        let grid:Vec<_>=anlz.beat_grid().unwrap_or_default().iter().filter_map(|b|u32::try_from(i64::from(b.time_ms)+offset).ok().map(|ms|(ms,b.beat_number,b.tempo_x100))).collect();
        let path=library.audio_path_of(&id).unwrap_or_default();
        let exists=Path::new(path).is_file();
        item["audioPath"]=serde_json::json!(path);item["exists"]=serde_json::json!(exists);
        item["grid"]=serde_json::json!(grid);
        println!("{}: audio {}, {} beats",item["title"],exists,grid.len());
        if args.get(3).is_some_and(|s|s=="analyse" || s=="structure") && exists {
            let audio=rbl_audio::decode_mono(Path::new(path),None)?;
            let beats:Vec<f64>=grid.iter().map(|b|f64::from(b.0)/1000.0).collect();
            let downbeats:Vec<f64>=grid.iter().filter(|b|b.1==1).map(|b|f64::from(b.0)/1000.0).collect();
            let bpm=item["bpm"].as_f64().unwrap_or(140.);
            if args.get(3).is_some_and(|s|s=="structure") {
                let frames=rbl_analysis::downbeat::band_frames(&audio.samples,audio.sample_rate);
                let phase=rbl_analysis::downbeat::grid_phase_from(&frames,audio.sample_rate,&beats);
                let profiles=rbl_analysis::downbeat::beat_profiles_from(&frames,audio.sample_rate,&downbeats);
                let timing=rbl_cueit::assess_grid_timing(&audio.samples,audio.sample_rate,&beats);
                std::fs::write(out.join(format!("structure-{}.json",id)),serde_json::to_vec(&serde_json::json!({"phraseStarts":phase.phrase_starts.iter().map(|t|t*1000.).collect::<Vec<_>>(),"barProfiles":profiles,"downbeatMs":phase.downbeat_secs*1000.,"confidence":phase.confidence,"beatAttacks":timing.beat_attacks,"timingSupport":timing.support,"timingOffsetMs":timing.offset_ms,"timingDriftMs":timing.drift_ms}))?)?;
                continue;
            }
            let result=rbl_cueit::analyse_on_export_grid(path,&audio.samples,audio.sample_rate,beats,bpm,downbeats)?;
            std::fs::write(out.join(format!("reference-{}.json",item["id"].as_str().unwrap())),serde_json::to_vec(&result)?)?;
        }
    }
    std::fs::write(out.join("reference-grids.json"),serde_json::to_vec(&refs)?)?;
    Ok(())
}
