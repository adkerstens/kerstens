$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$mixCargoBin = Join-Path $env:USERPROFILE '.cargo\bin'
$mixVsWhere = 'C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path -LiteralPath (Join-Path $mixCargoBin 'cargo.exe'))) { throw 'Installeer eerst Rust via rustup.' }
if (-not (Test-Path -LiteralPath $mixVsWhere)) { throw 'Microsoft C++ Build Tools ontbreken.' }
$mixVsRoot = & $mixVsWhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $mixVsRoot) { throw 'MSVC/Windows SDK ontbreken.' }
$mixPerl = 'C:\Strawberry\perl\bin\perl.exe'
$mixPortable = Join-Path $env:LOCALAPPDATA 'MixPilotBuild\perl-portable'
if (-not (Test-Path -LiteralPath $mixPerl)) { $mixPerl = Join-Path $mixPortable 'perl\bin\perl.exe' }
if (-not (Test-Path -LiteralPath $mixPerl)) { throw 'Installeer Strawberry Perl of pak de officiële portable versie uit in LocalAppData\MixPilotBuild\perl-portable.' }
$mixNode = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $mixNode) { throw 'Node.js ontbreekt.' }
$env:Path = $mixCargoBin + ';' + (Split-Path $mixNode.Source) + ';' + $env:Path
$env:OPENSSL_SRC_PERL = $mixPerl
$env:LC_ALL = 'C'
$env:LC_CTYPE = 'C'
$env:LANG = 'C'
$env:CARGO_TARGET_DIR = Join-Path $env:LOCALAPPDATA 'MixPilotBuild\target'
$env:RBXPORT_TEST = '1'
$mixVcVars = Join-Path $mixVsRoot 'VC\Auxiliary\Build\vcvars64.bat'
$mixBuildCommand = 'call "' + $mixVcVars + '" >nul && node node_modules\@tauri-apps\cli\tauri.js build --config src-tauri\tauri.mixpilot.conf.json --bundles nsis'
& cmd.exe /d /s /c $mixBuildCommand
if ($LASTEXITCODE -ne 0) { throw 'De Windows-bouw is mislukt; zie de foutmelding hierboven.' }
Write-Host ('Installer: ' + (Join-Path $env:CARGO_TARGET_DIR 'release\bundle\nsis'))
