//! Read-only diagnostics. Audio and analysis stay in the requested local output.
use std::path::{Path,PathBuf};
fn main()->Result<(),Box<dyn std::error::Error>> {
    let args:Vec<_>=std::env::args().collect();
    let out=Path::new(args.get(1).ok_or("output directory required")?);
    std::fs::create_dir_all(out)?;
    let db=rbl_db::Library::open_installed_read_only()?;
    let (mut library,_)=rbl_index::load(&db)?;
    if let Some(path)=std::env::var_os("BEATWARRIOR_REFERENCE_SNAPSHOT") {
        let bytes=std::fs::read(path)?;
        let u32_at=|i|u32::from_le_bytes(bytes[i..i+4].try_into().unwrap());
        let u64_at=|i|u64::from_le_bytes(bytes[i..i+8].try_into().unwrap());
        let fp=rbl_index::cache::Fingerprint{format:u32_at(4),db_len:u64_at(8),db_modified_ns:u64_at(16) as i64,wal_len:u64_at(24),wal_modified_ns:u64_at(32) as i64,db_version:u32_at(40),content:u64_at(44),database:u64_at(52)};
        library=rbl_index::cache::decode(&bytes,fp).ok_or("App snapshot could not be read")?;
        println!("Reference source: read-only app snapshot, {} tracks",library.len());
    }

    println!("Resolved database: {:?}",std::fs::canonicalize(&db.location().master_db)?);
    let mut query=db.connection().prepare("SELECT Name,rb_local_deleted FROM djmdPlaylist WHERE LOWER(Name) LIKE '%oblivion%'")?;
    let names=query.query_map([],|r|Ok((r.get::<_,String>(0)?,r.get::<_,i64>(1)?)))?;
    for name in names{println!("Raw reference: {:?}",name?);}

    {
        let playlists=library.playlists();
        println!("Library: {}",db.location().master_db.display());
        for i in 0..playlists.ids.len(){if playlists.names.get(i).to_lowercase().contains("oblivion"){println!("Reference candidate: {:?}",playlists.names.get(i));}}
        if let Some(p)=(0..playlists.ids.len()).find(|&i|playlists.names.get(i).trim().eq_ignore_ascii_case("Oblivion Final")) {
            let tracks:Vec<_>=playlists.members[p].iter().map(|&row|{
                let i=row as usize;
                let dat=rbl_anlz::resolve(&db.location().share_root,library.analysis_path.get(i));
                let grid=rbl_anlz::Anlz::read(&dat).ok().map(|a|{let offset=i64::from(a.grid_offset().unwrap_or(0));a.beat_grid().unwrap_or_default().iter().map(|b|serde_json::json!({"ms":i64::from(b.time_ms)+offset,"number":b.beat_number})).collect::<Vec<_>>()}).unwrap_or_default();
                serde_json::json!({"title":library.title.get(i),"path":library.audio_path_of(&library.ids[i].to_string()),"grid":grid,"cues":library.cues_of(row).iter().map(|c|serde_json::json!({"letter":c.hot_letter(),"ms":c.position_ms,"outMs":c.out_ms})).collect::<Vec<_>>()})
            }).collect();
            std::fs::write(out.join("manual-reference.json"),serde_json::to_vec(&tracks)?)?;
            println!("Read-only reference: Oblivion Final, {} tracks",tracks.len());
        } else {println!("Reference playlist not found in detected library");}
    }
    for (index,path) in args.iter().skip(2).enumerate() {
        let audio=rbl_audio::decode_mono(Path::new(path),None)?;
        let row=(0..library.ids.len()).find(|&i|library.audio_path_of(&library.ids[i].to_string()).is_some_and(|p|p.replace('\\',"/").eq_ignore_ascii_case(&path.replace('\\',"/"))));
        let mut stored=Vec::new();
        let mut stored_numbers=Vec::new();
        if let Some(row)=row {
            let dat=rbl_anlz::resolve(&db.location().share_root,library.analysis_path.get(row));
            if let Ok(anlz)=rbl_anlz::Anlz::read(&dat) {
                let offset=f64::from(anlz.grid_offset().unwrap_or(0))/1000.0;
                for beat in anlz.beat_grid().unwrap_or_default(){let t=f64::from(beat.time_ms)/1000.0+offset;if t>=0.0{stored.push(t);stored_numbers.push(beat.beat_number);}}
            }
        }
        let fresh=rbl_analysis::analyse_with(&audio.samples,audio.sample_rate,rbl_analysis::AnalysisPreset::Rekordbox.options());
        let fresh_beats:Vec<_>=fresh.tempo.beats.iter().map(|b|f64::from(b.time_ms)/1000.0).collect();
        let fresh_numbers:Vec<_>=fresh.tempo.beats.iter().map(|b|b.beat_number).collect();
        let beats=if stored.len()>8{stored.clone()}else{fresh_beats.clone()};
        let bpm=60.0/(beats[1]-beats[0]);
        let phase=rbl_analysis::downbeat::grid_phase(&audio.samples,audio.sample_rate,&beats);
        let cueit=rbl_cueit::analyse_on_grid(path,&audio.samples,audio.sample_rate,beats,bpm)?;
        let payload=serde_json::json!({"path":path,"sampleRate":audio.sample_rate,"storedBeats":stored,"storedNumbers":stored_numbers,"freshBeats":fresh_beats,"freshNumbers":fresh_numbers,"freshBpm":fresh.tempo.bpm,"structure":{"downbeat":phase.downbeat_secs,"halfBeatOff":phase.half_beat_off,"confidence":phase.confidence,"phrases":phase.phrase_starts},"cueit":cueit});
        std::fs::write(out.join(format!("track-{index}.json")),serde_json::to_vec(&payload)?)?;
        println!("{}: stored {} beats; fresh {:.3} BPM; structure first {:.3}s, half-beat {}, confidence {:.3}; CueIt first {:.3}s",PathBuf::from(path).file_name().unwrap().to_string_lossy(),stored.len(),fresh.tempo.bpm,phase.downbeat_secs,phase.half_beat_off,phase.confidence,cueit.analysis.downbeats.first().copied().unwrap_or(0.0));
    }
    Ok(())
}
