//! Thin bridge to the actual vendored CueIt engine, not a reimplementation.
pub use cueit_core::types::{AnalysisResult, Cue, CueSet, Section, TrackData};
pub const UPSTREAM_REVISION: &str = "f08ae3ef2979bb3e9e2c3d89279f631a7e25a65d";

pub fn analyse_pcm(path: &str, samples: &[f32], sample_rate: u32) -> Result<TrackData, String> {
    analyse_with(path, samples, sample_rate, &cueit_core::analysis::ModelOverrides::default())
}

/// CueIt's own supported override interface keeps an existing export beat grid
/// while CueIt itself detects its downbeat phase, structure and hot cues.
pub fn analyse_on_grid(path: &str, samples: &[f32], sample_rate: u32, beats: Vec<f64>, bpm: f64) -> Result<TrackData, String> {
    if beats.len()<8 || !bpm.is_finite() || bpm<=0.0 || beats.iter().any(|b| !b.is_finite() || *b<0.0) || beats.windows(2).any(|b| b[1]<=b[0]) {
        return Err("Ongeldige beatgrid voor CueIt".to_string());
    }
    analyse_with(path, samples, sample_rate, &cueit_core::analysis::ModelOverrides { beats: Some(beats), bpm: Some(bpm), ..Default::default() })
}

fn analyse_with(path: &str, samples: &[f32], sample_rate: u32, overrides: &cueit_core::analysis::ModelOverrides) -> Result<TrackData, String> {
    if sample_rate == 0 || samples.is_empty() || samples.iter().any(|v| !v.is_finite()) {
        return Err("Geen bruikbare audio voor CueIt".to_string());
    }
    std::panic::catch_unwind(|| {
        let analysis = cueit_core::analysis::analyze_pcm_with(path, samples, sample_rate, overrides, None);
        let cues = cueit_core::infer_cues(&analysis, true).cues;
        TrackData { path: path.to_string(), analysis, cues }
    }).map_err(|_| "CueIt kon dit audiobestand niet analyseren".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn invalid_pcm_is_an_error_not_an_app_panic() {
        assert!(analyse_pcm("empty", &[], 44100).is_err());
        assert!(analyse_pcm("invalid", &[f32::NAN], 44100).is_err());
        assert!(analyse_pcm("invalid", &[0.0], 0).is_err());
    }
    #[test]
    fn bridge_returns_the_actual_cueit_analysis_and_cues() {
        let sr = 22050; let mut samples = vec![0.0; sr as usize * 16];
        for beat in 0..32 {
            let start = beat * sr as usize / 2;
            for i in 0..300 { samples[start+i] = 0.8 * (-(i as f32)/50.0).exp(); }
        }
        let result = analyse_pcm("click.wav", &samples, sr).unwrap();
        let direct = cueit_core::analysis::analyze_pcm("click.wav", &samples, sr, None);
        assert_eq!(serde_json::to_value(&result.analysis).unwrap(), serde_json::to_value(&direct).unwrap());
        assert_eq!(result.cues, cueit_core::infer_cues(&direct, true).cues);
        assert!(!result.analysis.beats.is_empty());
        assert!(!result.analysis.downbeats.is_empty());
    }
    #[test]
    fn export_grid_is_preserved_but_cueit_detects_the_bar_phase() {
        let sr=22050; let samples=vec![0.0;sr as usize*16];
        let beats:Vec<f64>=(0..32).map(|i|i as f64*0.5).collect();
        let result=analyse_on_grid("silence.wav", &samples, sr, beats.clone(), 120.0).unwrap();
        assert_eq!(result.analysis.beats,beats);
        assert_eq!(result.analysis.bpm,120.0);
        assert!(result.analysis.downbeats.iter().all(|b|beats.contains(b)));
        assert_eq!(result.cues,cueit_core::infer_cues(&result.analysis,true).cues);
    }
}
