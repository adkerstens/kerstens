# MC Warrior animation assets — Beatwarrior 1.9.8

User-approved local photo animation, without video subscriptions or external playback services.

Both PNGs were edited with built-in imagegen in transparent-background mode. The original generated files are retained in the Codex generated_images directory. No image-processing script was used to change the pictures.

- `warrior-head-sprite.png`: two equal square frames; closed smile on the left, open shout on the right. Source: the user's portrait `1000143839.jpg` in the chat “Video remix maken”. The user explicitly asked to reuse that head. Imagegen prompt: create a two-frame photographic transparent sprite of the same head, identical scale, camera angle and eye placement; left happy closed-mouth smile, right cheerful wide-open mouth as in the reference; preserve identity, hair, skin, age, eyes and ears; remove neck, shirt and background; no text, glow, frame or cartoon styling.
- `warrior-dancer.png`: isolated MC Warrior, sourced from the user's supplied stage photo `codex-clipboard-3e57a128-3d06-4c9a-abdc-e1752f88c529.png`. Imagegen prompt: isolate only the smiling man at the left front, black T-shirt and shorts, tattooed arms, raised index finger and microphone; preserve his identity, outfit, proportions and pose; remove the venue and everyone else; include both feet, naturally reconstructing the tiny missing shoe area; center on a transparent near-square canvas with margin; photographic, no cartoon, text, outline or added effects.

Runtime: CSS transform animation for the dancer during USB export, requestAnimationFrame for the loading head. Clicking opens the mouth for 800 ms. Both respect reduced-motion preferences; movement and timers stop when the loading component unmounts. No sound or generated video is included. Playlist ordering, analysis and cue generation are unchanged in this cosmetic release.
