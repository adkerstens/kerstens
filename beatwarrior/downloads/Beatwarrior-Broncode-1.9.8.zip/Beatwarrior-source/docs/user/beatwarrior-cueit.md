# CueIt daadwerkelijk ingebouwd in Beatwarrior 1.9.5

## Complete automatische A/B/C-sets in 1.9.7

Analyse-onzekerheid leidt niet meer tot het overslaan van alle drie cues.
De automatische playlistmaker voltooit iedere set met de huidige metadata,
opgeslagen beatgrid en beschikbare audio. Bij een mislukte CueIt-analyse leest
de terugval het hoorbare begin/einde in begrensde vensters. Ontbrekende
maatposities worden als laatste terugval uit tempo en speelduur geschat;
bij zeer korte bestanden blijven drie verschillende punten binnen de duur.
Die terugval is een beste schatting, geen nieuwe claim van gemeten zekerheid.
De gezamenlijke overgangsplanner neemt ook deze voltooide kandidaten mee.

Het maken van een automatische playlist betekent nu expliciet dat A/B/C
opnieuw worden ingesteld, ook als die pads persoonlijke of anders benoemde
cues/loops bevatten. De native schrijver vervangt de gevraagde pads in een
transactie. Overige persoonlijke pads, memory cues en loops blijven behouden.
De aparte handmatige schrijfroute behoudt haar oude conflictcontrole.

Vlak voor het opslaan worden de actuele gegevens opnieuw ingelezen en worden
onvolledige plannen automatisch aangevuld. Na iedere batch leest Beatwarrior
de cues terug: precies drie live A/B/C-pads en hun berekende posities moeten
kloppen. Een tijdelijke fout krijgt een herpoging. Een echte opslagfout wordt
niet als geslaagd gemeld; opnieuw proberen hervat dezelfde playlist in deze
appsessie, zonder opnieuw een lege of dubbele playlist aan te maken.

Het normale eindscherm toont alleen de gemaakte playlist en het aantal nummers
met A/B/C. Aantallen onzekere overgangen en verzoeken om bestanden handmatig te
beoordelen zijn verwijderd. Diagnostiek blijft intern beschikbaar bij een echte
schrijffout. De CueIt-kern zelf blijft ongewijzigd.

Regressies bootsen de screenshot na: 78 nummers, 69 overgangscauties en 55
onvolledige analyses moeten 234 teruggelezen cues opleveren. Een native
databasefixture met 78 tracks controleert daarnaast daadwerkelijk opgeslagen
A/B/C-rijen na heropenen, bezette pads, herhaald schrijven, andere markers en
atomair herstel bij een afgebroken transactie. De tests schrijven niet in de
persoonlijke bibliotheek.

## Gezamenlijke overgangen in 1.9.6

Deze versie verfijnt de koppeling tussen opeenvolgende tracks. De originele
CueIt-kern blijft ongewijzigd. Uit de CueIt-analyse worden meerdere ritmische
frasebeginnen in de inkomende intro en bruikbare eindpunten in de uitgaande
outro afgeleid. De planner kiest A van de volgende track en B/C van de vorige
track samen, na het bepalen van de oplopende BPM-volgorde.

Daarbij geldt de regel uit de door de gebruiker aangeleverde tekst: kies eerst
de overname, tel de aanloop van de nieuwe track in maten en reken diezelfde
maten terug in de oude track. De upload `Geplakte tekst.txt` is hiervoor opnieuw
gelezen, inclusief het voorbeeld met 128 BPM, 3:00 instarten en 4:00 overnemen.
De lokale map `sources/` bevatte bij deze controle geen bestanden; er is geen
andere gesynchroniseerde muziekreferentie verondersteld.

Een CueIt-Outro-cue markeert vaak het begin van een outro, niet automatisch
het einde van de hele overgang. De planner kan C nu naar een later volledig
frase-einde verplaatsen als daar nog drums en voldoende geluid zijn. Een
lange inkomende intro kan op een later A-frasepunt beginnen om op een kortere
uitgaande outro te passen. Een gekozen A van een middentrack blijft behouden
bij het berekenen van diens volgende overgang. De hoofdgroove krijgt minimaal
een achtmaatsblok voor de volgende instart.

De gemeten drop wordt niet meer standaard naar een eerder veelvoud vanaf het
bestandsbegin afgerond. CueIt-landmarks bepalen de frasepositie, waardoor een
opmaat of ingevoegde maten de drop niet meerdere maten te vroeg maken.
De planner benut CueIts beat-low/RMS-metingen voor hoorbare ritmische A-punten,
uitgaande drumbezetting en het vermijden van stille staarten. Overlap met hoge
energie in beide tracks telt als minder gunstig. Dit is geen zang-/stemisolatie.

De aansluiting wordt op iedere maatgrens van de overlap gecontroleerd, met
de native BPM's omgerekend naar hetzelfde afspeeltempo. Gelijke aantallen maten
moeten dezelfde voortgang hebben; meer dan 0,08 beat relatieve afwijking geeft
een waarschuwing. Deze cueplanning past geen afspeeltempo, EQ of faders aan.
Tijdens het draaien moeten de decktempo's overeenkomen, zoals ook in de
aangeleverde uitleg staat.

Nieuwe regressietests dekken het geuploade 128-BPM-voorbeeld, 32 intro-/16
outromaten, uitgestelde drumstart, een uitgaande break, een stille staart,
verschillende native BPM's, tussentijdse griddrift en drie gekoppelde tracks.
Het betreft berekeningstests met bekende grenzen. Zonder een opgegeven echte
muziekmap/trackcombinatie is dit geen beluisterde acceptatie van de gebruikersset.

## Oorspronkelijke integratie in 1.9.5

De automatische playlistmaker roept vanaf deze versie de echte
[CueIt Rust-kern](https://github.com/CurePortal/Cueit) aan. De volledige
`cueit-core`-bronboom is gekopieerd uit versie `0.2.0-alpha.2`, revisie
`f08ae3ef2979bb3e9e2c3d89279f631a7e25a65d`. Alle vijftien gekopieerde
bestanden, inclusief de licentie en upstream-README, zijn met hun Git-blobhash
gecontroleerd. De algoritmen zijn ongewijzigd overgenomen; dit is geen nieuwe
implementatie op basis van alleen de documentatie.

## Actieve verwerking

Beatwarrior decodeert de geselecteerde audio met de bestaande ingebouwde
decoder. De PCM-buffer gaat rechtstreeks naar CueIts `analyze_pcm_with` en
daarna naar `infer_cues(..., true)`. De originele CueIt-code voert de analyse
van ritme, klank/MFCC, toonhoogte, luidheid, secties en cuekandidaten uit.

CueIts ondersteunde `ModelOverrides`-invoer krijgt de beatposities en BPM uit
de bestaande exportbibliotheek. CueIt bepaalt zelf de maatpositie, structuur,
fraselengte en cues. Deze bestaande beatposities voorkomen dat cues worden
geschreven op een andere tijdgrid dan de grid die naar de USB wordt gestuurd.
Als CueIt een andere maatnummering vindt, gebruikt Beatwarrior de gewone
grideditor om die nummering aan te passen. Een vergrendelde of beveiligde grid
wordt niet geforceerd overschreven.

CueIts originele Intro-, Drop- en Outro-cues worden naar Beatwarriors vaste
A/B/C-workflow vertaald. Daarbij worden de posities op hele, door CueIt
bepaalde frases gezet. A start de inkomende track; B op de uitgaande track
start de volgende A; C is de geplande overname. De overlap wordt in gehele
maten bepaald, niet door een vaste hoeveelheid seconden. Is er geen bruikbare
Drop/Outro-combinatie, dan volgt een begrensde overlap in hele frases met een
waarschuwing. De volledige originele analyse en CueIt-cues zijn beschikbaar via
de interne analyseaanroep; alleen de gevraagde A/B/C-pads worden geschreven.

De eerder ontwikkelde eigen frase-analyse blijft als broncode en geteste
hulpfunctie aanwezig, maar is niet de actieve analyseweg van de playlistmaker.
Een mislukte CueIt-analyse valt niet stilzwijgend terug op die eigen detector:
het nummer blijft in de playlist met behoud van bestaande cues en een melding.

De playlist blijft strikt oplopend in de opgeslagen BPM; de toonhoogte bepaalt
de volgorde binnen gelijke BPM. Onbekende BPM komt achteraan. Een onzekere
overgang of mislukte cue-update blokkeert de playlist niet. De bibliotheek,
spelers en USB-export blijven binnen hetzelfde Beatwarrior-venster werken.

## Wat is meegeleverd

De volledige gedeelde CueIt-kern bevat ook import/export-, sessie-, batch- en
optionele modelmodules. De host bouwt de kern met `default-features=false`:
audio komt van Beatwarriors decoder, database/USB-export blijft bij de
bestaande rbxport-motor. De aparte CueIt-GUI/CLI wordt niet gestart. De
optionele ONNX-modellen en hun downloads zijn niet geactiveerd; de actieve
cueberekening is CueIts oorspronkelijke pure-Rust-route. Dit is dus geen
claim dat alle losse CueIt-appschermen of modelopties zijn toegevoegd.

De MIT-auteursvermelding en toestemming staan bij de broncode en in het
geinstalleerde programma onder `licenses/CueIt-MIT.txt`. De herkomstlijst staat
ernaast als `CueIt-UPSTREAM.json`. De bestaande GPL-licentie van Beatwarriors
rbxport-basis blijft van toepassing op de afgeleide app.

## Controle en grenzen

De eigen tests van CueIt zijn uitgevoerd. De adaptertests vergelijken analyse
en cue-inferentie rechtstreeks met calls naar de oorspronkelijke CueIt-code.
Beatwarrior-tests controleren de eenheden seconden/milliseconden, maatcorrectie,
frasegrenzen, A/B/C-overlap, oplopende BPM en behoud van de playlist bij fouten.
Alle schrijftests gebruiken fixtures, niet de persoonlijke muziekbibliotheek.

CueIt noemt deze versie zelf een alpha en vermeldt dat de cueheuristiek nog
wordt afgestemd op gelabelde tracks. Integratie maakt die heuristiek niet
onfeilbaar. De oorspronkelijke trackselectie is nog niet op gehoor gevalideerd.
Nieuwe berekeningen worden toegepast wanneer je een playlist opnieuw maakt;
bestaande playlists veranderen niet automatisch door alleen de update.
