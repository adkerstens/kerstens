//! Thin bridge to the actual vendored CueIt engine, not a reimplementation.
pub use cueit_core::types::{AnalysisResult, Cue, CueSet, Section, TrackData};
pub const UPSTREAM_REVISION: &str = "f08ae3ef2979bb3e9e2c3d89279f631a7e25a65d";

/// Audio evidence across the track, independent of cue or bar labels.
pub struct GridTiming {
    pub support: f64,
    pub offset_ms: f64,
    pub drift_ms: f64,
    pub beat_attacks: Vec<bool>,
}

pub fn assess_grid_timing(samples:&[f32],sample_rate:u32,beats:&[f64])->GridTiming {
    let map=rbl_analysis::attack::AttackMap::new(samples,sample_rate,Default::default());
    let hits:Vec<_>=beats.iter().enumerate().filter_map(|(i,&t)|map.attack_near(t).map(|a|(i,(a.secs-t)*1000.0,a.height))).collect();
    let peak=hits.iter().map(|h|h.2).fold(0.0_f64,f64::max);
    let strong:Vec<_>=hits.into_iter().filter(|h|h.2>1e-7 && h.2>=peak*0.05).collect();
    let median=|mut xs:Vec<f64>| {xs.sort_by(f64::total_cmp);xs.get(xs.len()/2).copied().unwrap_or(0.0)};
    let early:Vec<_>=strong.iter().filter(|h|h.0<beats.len()/3).map(|h|h.1).collect();
    let late:Vec<_>=strong.iter().filter(|h|h.0>=beats.len()*2/3).map(|h|h.1).collect();
    let drift=if early.len()>=8 && late.len()>=8{median(late)-median(early)}else{0.0};
    let mut beat_attacks=vec![false;beats.len()];
    for hit in &strong {beat_attacks[hit.0]=true;}
    GridTiming{beat_attacks,support:strong.len() as f64/beats.len().max(1) as f64,offset_ms:median(strong.iter().map(|h|h.1).collect()),drift_ms:drift}
}

pub fn analyse_pcm(path: &str, samples: &[f32], sample_rate: u32) -> Result<TrackData, String> {
    analyse_with(path, samples, sample_rate, &cueit_core::analysis::ModelOverrides::default())
}

/// CueIt's own supported override interface keeps an existing export beat grid
/// while CueIt itself detects its downbeat phase, structure and hot cues.
pub fn analyse_on_grid(path: &str, samples: &[f32], sample_rate: u32, beats: Vec<f64>, bpm: f64) -> Result<TrackData, String> {
    if beats.len()<8 || !bpm.is_finite() || bpm<=0.0 || beats.iter().any(|b| !b.is_finite() || *b<0.0) || beats.windows(2).any(|b| b[1]<=b[0]) {
        return Err("Ongeldige beatgrid voor CueIt".to_string());
    }
    analyse_with(path, samples, sample_rate, &cueit_core::analysis::ModelOverrides { beats: Some(beats), bpm: Some(bpm), ..Default::default() })
}

/// Use the bar count written by the audio/grid analyser. CueIt's four-phase
/// average-accent vote must not renumber an already verified export grid.
pub fn analyse_on_export_grid(path: &str, samples: &[f32], sample_rate: u32, beats: Vec<f64>, bpm: f64, downbeats: Vec<f64>) -> Result<TrackData, String> {
    if beats.len()<8 || !bpm.is_finite() || bpm<=0.0 || beats.iter().any(|b|!b.is_finite() || *b<0.0) || beats.windows(2).any(|b|b[1]<=b[0]) || downbeats.is_empty() {
        return Err("Ongeldige exportgrid voor CueIt".to_string());
    }
    let indices:Option<Vec<usize>>=downbeats.iter().map(|time|beats.iter().position(|b|b==time)).collect();
    let Some(indices)=indices else{return Err("Maatbegin ligt niet op de exportgrid".to_string());};
    if indices[0]>3 || indices.windows(2).any(|w|w[1]!=w[0]+4) {
        return Err("Ongeldige maatnummering voor CueIt".to_string());
    }
    let confidence=rbl_analysis::downbeat::grid_phase(samples,sample_rate,&beats).confidence;
    analyse_with(path,samples,sample_rate,&cueit_core::analysis::ModelOverrides{beats:Some(beats),bpm:Some(bpm),downbeats:Some(downbeats),downbeat_confidence:Some(confidence),..Default::default()})
}

fn analyse_with(path: &str, samples: &[f32], sample_rate: u32, overrides: &cueit_core::analysis::ModelOverrides) -> Result<TrackData, String> {
    if sample_rate == 0 || samples.is_empty() || samples.iter().any(|v| !v.is_finite()) {
        return Err("Geen bruikbare audio voor CueIt".to_string());
    }
    std::panic::catch_unwind(|| {
        let analysis = cueit_core::analysis::analyze_pcm_with(path, samples, sample_rate, overrides, None);
        let cues = cueit_core::infer_cues(&analysis, true).cues;
        TrackData { path: path.to_string(), analysis, cues }
    }).map_err(|_| "CueIt kon dit audiobestand niet analyseren".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn invalid_pcm_is_an_error_not_an_app_panic() {
        assert!(analyse_pcm("empty", &[], 44100).is_err());
        assert!(analyse_pcm("invalid", &[f32::NAN], 44100).is_err());
        assert!(analyse_pcm("invalid", &[0.0], 0).is_err());
    }
    #[test]
    fn bridge_returns_the_actual_cueit_analysis_and_cues() {
        let sr = 22050; let mut samples = vec![0.0; sr as usize * 16];
        for beat in 0..32 {
            let start = beat * sr as usize / 2;
            for i in 0..300 { samples[start+i] = 0.8 * (-(i as f32)/50.0).exp(); }
        }
        let result = analyse_pcm("click.wav", &samples, sr).unwrap();
        let direct = cueit_core::analysis::analyze_pcm("click.wav", &samples, sr, None);
        assert_eq!(serde_json::to_value(&result.analysis).unwrap(), serde_json::to_value(&direct).unwrap());
        assert_eq!(result.cues, cueit_core::infer_cues(&direct, true).cues);
        assert!(!result.analysis.beats.is_empty());
        assert!(!result.analysis.downbeats.is_empty());
    }
    #[test]
    fn export_grid_is_preserved_but_cueit_detects_the_bar_phase() {
        let sr=22050; let samples=vec![0.0;sr as usize*16];
        let beats:Vec<f64>=(0..32).map(|i|i as f64*0.5).collect();
        let result=analyse_on_grid("silence.wav", &samples, sr, beats.clone(), 120.0).unwrap();
        assert_eq!(result.analysis.beats,beats);
        assert_eq!(result.analysis.bpm,120.0);
        assert!(result.analysis.downbeats.iter().all(|b|beats.contains(b)));
        assert_eq!(result.cues,cueit_core::infer_cues(&result.analysis,true).cues);
    }
    #[test]
    fn verified_red_beats_survive_louder_accents_on_beat_three() {
        let sr=8000;let mut samples=vec![0.0;sr as usize*24];
        let beats:Vec<f64>=(0..48).map(|i|i as f64*0.5).collect();
        for (i,t) in beats.iter().enumerate(){for j in 0..160{let at=(*t*f64::from(sr)) as usize+j;samples[at]=if i%4==2{0.9}else{0.2}*(-(j as f32)/30.0).exp();}}
        let downbeats:Vec<f64>=beats.iter().step_by(4).copied().collect();
        let result=analyse_on_export_grid("accents.wav",&samples,sr,beats.clone(),120.0,downbeats.clone()).unwrap();
        assert_eq!(result.analysis.beats,beats);
        assert_eq!(result.analysis.downbeats,downbeats);
        assert!(result.cues.iter().filter(|c|c.name=="Intro").all(|c|c.time==0.0));
    }
    #[test]
    fn invalid_red_beat_sequence_is_rejected() {
        let beats:Vec<f64>=(0..32).map(|i|i as f64*0.5).collect();
        assert!(analyse_on_export_grid("x",&[0.;100],8000,beats.clone(),120.,vec![0.,2.,3.]).is_err());
        assert!(analyse_on_export_grid("x",&[0.;100],8000,beats,120.,vec![0.1,2.1]).is_err());
    }
    #[test]
    fn timing_check_measures_onset_offset_and_drift_across_the_track() {
        let sr=22050;let beats:Vec<f64>=(0..80).map(|i|1.0+i as f64*0.5).collect();
        let mut samples=vec![0.0;sr as usize*42];
        for (i,t) in beats.iter().enumerate(){let offset=0.003+i as f64*0.00010;let at=((t+offset)*f64::from(sr)) as usize;
            for j in 0..500 {samples[at+j]=((j as f32)*2.0*std::f32::consts::PI*2400.0/sr as f32).sin()*(-(j as f32)/60.0).exp();}}
        let timing=assess_grid_timing(&samples,sr,&beats);
        assert!(timing.support>0.9,"{}",timing.support);
        assert!((3.0..=12.0).contains(&timing.offset_ms),"{}",timing.offset_ms);
        assert!((3.0..=8.0).contains(&timing.drift_ms),"{}",timing.drift_ms);
        let wrong:Vec<_>=beats.iter().map(|t|t+0.1).collect();
        assert!(assess_grid_timing(&samples,sr,&wrong).support<0.1);
    }
    #[test]
    fn beatless_audio_is_not_reported_as_timing_verified() {
        let beats:Vec<f64>=(0..32).map(|i|i as f64*0.5).collect();
        let timing=assess_grid_timing(&vec![0.0;22050*16],22050,&beats);
        assert_eq!(timing.support,0.0);assert_eq!(timing.offset_ms,0.0);
    }

}
