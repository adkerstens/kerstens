import assert from "node:assert/strict";
import test from "node:test";

import { planValidation, validationKeys } from "./validation-plan.mjs";

function enabled(...paths) {
  const plan = planValidation(paths);
  return validationKeys.filter(key => plan[key]);
}

test("documentation-only changes require no expensive validation lane", () => {
  assert.deepEqual(enabled("README.md", "docs/testing.md", ".github/workflows/README.md"), []);
});

test("a Rust library change stays in the focused Rust lane", () => {
  assert.deepEqual(enabled("crates/rbl-db/src/export.rs"), ["rust"]);
});

test("desktop shell changes use focused Rust checks before deploy", () => {
  assert.deepEqual(enabled("src-tauri/src/lib.rs"), ["rust"]);
});

test("Windows installer resources add the Windows-native check", () => {
  assert.deepEqual(enabled("src-tauri/windows/install-update-task.ps1"), ["rust", "windows_rust"]);
});

test("Windows-only desktop Rust adds the Windows-native check", () => {
  assert.deepEqual(enabled("src-tauri/src/file_drop.rs"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("src-tauri/Cargo.toml"), ["rust", "windows_rust"]);
});

test("the library's Windows file-index code runs the Windows-native Rust lane", () => {
  assert.deepEqual(enabled("crates/rbl-db/src/file_id.rs"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("crates/rbl-db/Cargo.toml"), ["rust", "windows_rust"]);
});

test("USB eject's Windows code runs the Windows-native Rust lane", () => {
  assert.deepEqual(enabled("crates/rbl-devices/src/eject.rs"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("crates/rbl-devices/src/eject/windows.rs"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("crates/rbl-devices/Cargo.toml"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("crates/rbl-devices/src/lib.rs"), ["rust"]);
});

test("backup changes also run the Windows-native Rust lane", () => {
  assert.deepEqual(enabled("src-tauri/src/backups.rs"), ["rust", "windows_rust"]);
  assert.deepEqual(enabled("crates/rbl-backup/src/restore.rs"), ["rust", "windows_rust"]);
});

test("frontend test-only changes skip browser and bundle checks", () => {
  assert.deepEqual(enabled("src/lib/cues.test.ts"), [
    "frontend_lint",
    "frontend_typecheck",
    "frontend_unit",
  ]);
});

test("frontend source changes use the fast frontend checks", () => {
  assert.deepEqual(enabled("src/views/player/useGridEditor.ts"), [
    "frontend_lint",
    "frontend_typecheck",
    "frontend_unit",
  ]);
});

test("Playwright-only changes run lint, build, and browser tests", () => {
  assert.deepEqual(enabled("e2e/grid-edit.spec.ts"), [
    "frontend_lint",
    "frontend_typecheck",
    "frontend_build",
    "frontend_e2e",
  ]);
});

test("file-drop bridge changes add the Windows-native check", () => {
  assert.deepEqual(enabled("src/ipc/file-drop.ts"), [
    "frontend_lint",
    "frontend_typecheck",
    "frontend_unit",
    "windows_file_drop",
  ]);
});

test("release scripts use the focused Node script suite", () => {
  assert.deepEqual(enabled("scripts/generate-release-notes.mjs"), ["scripts"]);
});

test("the Vitest-based cleanup script also runs frontend unit tests", () => {
  assert.deepEqual(enabled("scripts/cleanup.mjs"), ["frontend_unit", "scripts"]);
});

test("packaging action changes defer expensive runtime checks to deploy", () => {
  assert.deepEqual(enabled(".github/actions/package-installer/action.yml"), ["scripts"]);
});

test("the AppImage GTK plugin runs the Node script suite that tests its hook", () => {
  assert.deepEqual(enabled("packaging/appimage/linuxdeploy-plugin-gtk.sh"), ["scripts"]);
});

test("a lane workflow change exercises only that lane on the PR", () => {
  assert.deepEqual(enabled(".github/workflows/validate-windows.yml"), [
    "scripts",
    "windows_rust",
    "windows_file_drop",
  ]);
});

test("manual validation enables every lane", () => {
  assert.deepEqual(
    validationKeys.filter(key => planValidation([], { all: true })[key]),
    validationKeys,
  );
});
