# Beatwarrior 1.9.4: BPM en fraseonderzoek

Onderzocht op 29 oktober 2026. Doel: geen dalende BPM in de automatische
playlist en cuepunten op de muzikale grote een, niet op een willekeurige maat.

## Wat de onderzochte projecten daadwerkelijk doen

| Bron | Bevinding uit documentatie/code | Gevolg voor Beatwarrior |
| --- | --- | --- |
| [Mixxx intro/outro en AutoDJ](https://mixxx.org/news/2020-07-09-intro-outro-sections/) en [huidige transition-code](https://github.com/mixxxdj/mixxx/blob/main/src/library/autodj/autodjprocessor.cpp) | Intro en outro zijn secties met begin/einde. De duur en het afspeeltempo bepalen de overlap. Stiltegrenzen leveren op zichzelf geen muzikale sectieherkenning. | B is het begin van de overlap, C de overname. Vergelijk hele aantallen maten met het intro van de volgende track. |
| [Automatic Cuepoints, lokale CBM-engine](https://github.com/shiva-menta/automatic-cuepoints/blob/52cd53115305cef683c1fd7f7c3046949b5c42c9/track_interface/cuepoint_engines/cbm_engine.py) | Middelt log-melspectra per maat, berekent self-similarity en zoekt segmenten met dynamische programmering. De standaardinstellingen geven voorkeur aan achtmaatsstructuur; ze zijn geen bewijs van een drop. | Neem klankstructuur over het hele nummer mee. Onderscheid maatgrenzen van frasegrenzen. Gebruik niet alleen volume of een losse kick. |
| [Marmoret, Cohen en Bimbot: Barwise Music Structure Analysis](https://doi.org/10.5334/tismir.167) | Wetenschappelijke basis voor vergelijking en segmentatie op maatniveau. Goede maatposities zijn een voorwaarde; structurele segmentatie is een aparte taak. | Eerst opgeslagen beat/maatgrid controleren, daarna frasepositie afleiden. |
| [AutoMix AI analyzer](https://github.com/harrisonoest/automix-ai/blob/main/automix/analyzer.py) | Combineert energie, sectie, spectrum en frasekandidaten. Een eenvoudige fallback telt vanaf de beatlijst. In de gelezen helper wordt ook met 16/32 beatindices gewerkt; dat is niet hetzelfde als 16/32 maten. | Een exportcue moet een gecontroleerde maatindex zijn. Vermijd verwarring tussen beats, maten en frases en kopieer geen vaste tijds-/indexregel blind. |
| [All-In-One](https://github.com/mir-aidj/all-in-one/blob/main/README.md) | Leert BPM, beats, downbeats en functionele secties. Vereist PyTorch, NATTEN en madmom; de Cuepoints-app biedt deze route via een externe rekendienst aan. | Relevante toekomstige vergelijkingsbron, maar deze zwaardere modelstack is niet ingebouwd. Beatwarrior blijft lokaal en zelfstandig. |

Geen broncode, modelgewichten of muziekbestanden zijn uit deze projecten
overgenomen. De nieuwe lichte implementatie is zelfstandig geschreven.

## Wat versie 1.9.4 verandert

De automatische playlist sorteert eerst strikt op oplopende, opgeslagen BPM.
Bij exact gelijke BPM kiest toonsoort de volgende track. De sleutel mag nooit
meer een stap terug in BPM veroorzaken. Ontbrekende BPM blijft herkenbaar als
onbekend; die nummers blijven achteraan in dezelfde playlist staan. Een gat
van bijvoorbeeld 110 naar 150 kan niet worden opgelost als geen tussenliggende
tracks zijn geselecteerd. Beatwarrior verzint hiervoor geen BPM en laat geen
nummers stilzwijgend weg.

De bestaande analyse van het hele audiobestand levert nu ook twaalf
frequentiebanden per opgeslagen maat. Deze beschrijvingen worden gecombineerd
met energie en drumbezetting. Vergelijking van vier- en achtmaatsvensters aan
weerszijden van een grens zoekt duurzame veranderingen. Veranderingen over het
hele nummer, spectrale pieken en sectielabels stemmen samen over de positie
binnen een achtmaatsblok. Een opmaat kan daardoor een verschoven frasepositie
opleveren; maat nul van het bestand is niet automatisch de muzikale grote een.

A kiest het vroegste stabiele ritmische frasebegin. B en C moeten ook op
frasegrenzen liggen. Voor een passende volgende track is het aantal maten van
B naar C gelijk aan dat van de volgende A naar de gekozen drop/introgrens.
Bij een ongeldige combinatie volgt een overlap van hele frases en een melding.
Er komt geen verkorte drie-/viermaatsfallback. Vlak voor het schrijven worden
de maatgrid, A/B/C-posities en frasegrenzen opnieuw getoetst.

Dit is een frasepositie op basis van regelmatige danceblokken, geen volledige
CBM-implementatie. De referenties zijn vertaald naar de bestaande lichte motor,
niet letterlijk vervangen door een van de onderzochte programma's.

## Toetsing en grenzen

Nieuwe tests controleren de opgegeven reeks 145,150,145,142,140, decimalen,
78 tracks, harmonische uitzonderingen en onbekende BPM. Muzikale fixtures
testen een drumstart op de derde/vierde maat, een luidere fill, klankverandering
bij gelijk volume, een opmaat, en een ongeldige drop midden in een frase.
De bestaande tests voor maatcorrectie, A/B/C, playlistbehoud en cuebehoud blijven
van toepassing. De Windows-build controleert ook de nieuwe native datakoppeling.

De testfixtures hebben bekende muzikale grenzen. Dit bewijst niet dat iedere
commerciële house-, hardstyle- of hardcoretrack dezelfde structuur volgt.
Toegevoegde twee-/viermaatsbreaks, tempowisselingen, zangoverlap en afwijkende
edits kunnen controle op gehoor vragen. De fasezekerheid is een heuristische
scheiding, geen gekalibreerde kans. Onzekerheid blijft een waarschuwing en
blokkeert het aanmaken van de playlist niet. Persoonlijke cues blijven behouden.

De oorspronkelijke trackselectie is niet als beluisterde en door een DJ
geannoteerde acceptatieset gecontroleerd. Daarom claimt deze versie geen
perfecte automatische overgangen voor alle muziek.
