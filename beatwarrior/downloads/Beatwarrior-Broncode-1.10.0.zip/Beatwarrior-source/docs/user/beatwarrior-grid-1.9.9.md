# Beatwarrior 1.9.9: grid, intro en frase

De CueIt-broncode blijft ongewijzigd. De brug gebruikt CueIts ondersteunde
beat- en downbeat-overrides voor de werkelijk opgeslagen exportgrid. De
spectrale structurele fasecontrole beslist over de maatnummering, niet een
tweede gemiddelde-accentstemming in CueIt. Leescommando's passen nu dezelfde
PQTZ-offset toe als de grideditor.

Voorbereiding toetst aanslagen over het hele bestand. Onvoldoende aansluiting
of meetbare drift leidt tot heranalyse; een passende bestaande (ook variabele)
grid wordt behouden. Kleine timingverschuivingen en sterke fasecorrecties
worden op de opgeslagen grid toegepast. Daarna werkt CueIt op precies die
maatposities. Een CueIt-resultaat met afwijkende nummering wordt geweigerd.

De planner combineert CueIt-beatenergie, lage frequenties en secties met
bargewijze spectra en terugkerende structurele frasegrenzen. Een intacte
openende drumintro blijft het begin. Een vertraagde drumintro gebruikt
frasebewijs; een kick op zichzelf bewijst geen nieuwe frase. Geselecteerde
A blijft vast tijdens het plannen van de volgende aansluitingen. Het eerste
bruikbare introdoel heeft voorrang boven een late, prominente hoofd-drop.
Fill/riser-kandidaten worden lokaal getoetst op een aanhoudende drumterugkeer.
De inkomende aanloop eindigt v��r de eerste breakdown. De uitgaande track
mag eerder een geschikte frase gebruiken als de outro onvoldoende bruikbare
maten bevat. B begint bij voorkeur met een aanslag op de eerste tel en sluit aan in hele
maten. Herstelde grids verliezen verouderde ritme-indexen.

## Controle en grenzen

- Algemene regressies: uiteenlopende BPM's, opmaten, frasefasen, beatloze
  intro's, ontbrekende eerste kick, vroege fills, late hoofd-drops, opgeslagen
  grid-offset en afwijkende CueIt-maatnummering.
- De 23 door de gebruiker aangewezen referentienummers zijn alleen uitgelezen;
  de eigen cues en muziekbestanden zijn niet gewijzigd. Referentiemuziek en
  persoonlijke exports zijn geen onderdeel van de broncodedistributie.
- Op een rood punt liggen is een controleerbare grid-eigenschap. Of het grid
  muzikaal correct is en een frase de gewenste mixkeuze is, blijft een
  audioanalyse-schatting. Dit is geen bewijs dat ieder genre of elke opname
  automatisch perfect werkt. Geen fysieke CDJ/RX2-acceptatietest uitgevoerd.
- De bestaande automatische aanvulling blijft beschikbaar als analyse niet
  kan voltooien; deze levert beschikbare beste schattingen, geen garantie van
  gemeten muzikale grenzen. De playlist laat geen nummer weg vanwege lage
  analyseconfidence.

Controle op de 23 referentie-opnames: 69 cues op opgeslagen rode gridpunten
en berekende frasegrenzen, A/B met gemeten aanslag, 22 van 22 aansluitingen
met gelijke maten en gemeenschappelijk-tempo timing. Dit zijn rekenkundige
controles op deze opnames, geen algemene garantie van muzikale perfectie.
