//! Reversible cue cleanup on throwaway libraries only.
#![allow(clippy::unwrap_used,clippy::expect_used,clippy::panic)]
use rbl_db::{fixture::{self,Shape,track_id},write::Writer};
fn open()->(tempfile::TempDir,Writer){let dir=tempfile::tempdir().unwrap();let loc=fixture::build(dir.path(),Shape::default()).unwrap();let mut w=Writer::open(loc,dir.path().join("backup")).unwrap();w.disable_automatic_backups();(dir,w)}
fn count(w:&Writer,track:&str)->i64{w.library().connection().query_row("SELECT COUNT(*) FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0",[track],|r|r.get(0)).unwrap()}
fn fill(w:&mut Writer,track:&str){let h=w.add_cue(track,1,137).unwrap();w.set_cue_comment(&h,"Personal A").unwrap();w.add_cue(track,0,800).unwrap();w.add_loop(track,0,2000,4000,4).unwrap();}
fn snapshot(w:&Writer,track:&str)->Vec<(String,i64,i64,u8,String)>{let mut q=w.library().connection().prepare("SELECT ID,InMsec,COALESCE(OutMsec,0),Kind,COALESCE(Comment,'') FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0 ORDER BY ID").unwrap();let rows=q.query_map([track],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?,r.get(4)?))).unwrap();rows.collect::<rusqlite::Result<_>>().unwrap()}
#[test]
fn playlist_clear_and_undo_cover_hot_memory_and_loops_without_touching_other_tracks(){
 let (_dir,mut w)=open();let a=track_id(0);let b=track_id(1);let other=track_id(2);fill(&mut w,&a);fill(&mut w,&b);fill(&mut w,&other);
 let old=w.add_cue(&a,2,500).unwrap();w.delete_cue(&old).unwrap();
 let p=w.create_playlist("Selected","root").unwrap();w.add_tracks_allowing(&p,&[a.clone(),a.clone(),b.clone()],true).unwrap();
 let shared=w.create_playlist("Shared","root").unwrap();w.add_tracks(&shared,&[a.clone(),other.clone()]).unwrap();
 let before_a=snapshot(&w,&a);let before_b=snapshot(&w,&b);let before_other=snapshot(&w,&other);
 let clear=w.clear_playlist_cues(&p).unwrap();assert!(!clear.is_empty());assert_eq!(count(&w,&a),0);assert_eq!(count(&w,&b),0);assert_eq!(snapshot(&w,&other),before_other);
 let members:i64=w.library().connection().query_row("SELECT COUNT(*) FROM djmdSongPlaylist WHERE PlaylistID=?1 AND rb_local_deleted=0",[&p],|r|r.get(0)).unwrap();assert_eq!(members,3);
 w.replay_playlist_cue_clear(&clear,true).unwrap();assert_eq!(snapshot(&w,&a),before_a);assert_eq!(snapshot(&w,&b),before_b);assert!(w.cue_owner(&old).unwrap().is_none());
 w.replay_playlist_cue_clear(&clear,false).unwrap();assert_eq!(count(&w,&a),0);assert_eq!(count(&w,&b),0);assert_eq!(snapshot(&w,&other),before_other);
}
#[test]
fn single_track_clear_does_not_expand_to_its_playlist(){let (_dir,mut w)=open();let a=track_id(0);let b=track_id(1);fill(&mut w,&a);fill(&mut w,&b);let p=w.create_playlist("Both","root").unwrap();w.add_tracks(&p,&[a.clone(),b.clone()]).unwrap();let before=snapshot(&w,&a);let clear=w.clear_track_cues(&[a.clone()]).unwrap();assert_eq!(count(&w,&a),0);assert_eq!(count(&w,&b),3);w.replay_playlist_cue_clear(&clear,true).unwrap();assert_eq!(snapshot(&w,&a),before);}
#[test]
fn clear_rolls_back_if_any_update_fails(){let (_dir,mut w)=open();let a=track_id(0);fill(&mut w,&a);w.add_cue(&a,3,6000).unwrap();let before=snapshot(&w,&a);let p=w.create_playlist("P","root").unwrap();w.add_tracks(&p,&[a.clone()]).unwrap();w.library().connection().execute_batch("CREATE TRIGGER fail_clear BEFORE UPDATE OF rb_local_deleted ON djmdCue WHEN OLD.Kind=3 BEGIN SELECT RAISE(FAIL,'fixture clear failure');END;").unwrap();assert!(w.clear_playlist_cues(&p).is_err());assert_eq!(snapshot(&w,&a),before);}
#[test]
fn undo_refuses_new_pad_conflicts_without_partial_restore(){let (_dir,mut w)=open();let a=track_id(0);fill(&mut w,&a);let before=snapshot(&w,&a);let clear=w.clear_track_cues(&[a.clone()]).unwrap();let new=w.add_cue(&a,1,9000).unwrap();assert!(w.replay_playlist_cue_clear(&clear,true).is_err());assert_eq!(count(&w,&a),1);assert!(w.cue_owner(&new).unwrap().is_some());w.delete_cue(&new).unwrap();w.replay_playlist_cue_clear(&clear,true).unwrap();assert_eq!(snapshot(&w,&a),before);}
#[test]
fn invalid_and_empty_scopes_do_not_change_any_cues(){let (_dir,mut w)=open();let a=track_id(0);fill(&mut w,&a);let before=snapshot(&w,&a);assert!(w.clear_playlist_cues("missing").is_err());assert!(w.clear_track_cues(&[a.clone(),"missing".into()]).is_err());assert!(w.clear_track_cues(&[]).is_err());let p=w.create_playlist("Empty","root").unwrap();assert!(w.clear_playlist_cues(&p).unwrap().is_empty());assert_eq!(snapshot(&w,&a),before);}
