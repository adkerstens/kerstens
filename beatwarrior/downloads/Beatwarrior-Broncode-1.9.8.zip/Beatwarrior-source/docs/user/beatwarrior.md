# Beatwarrior fork

Beatwarrior is a local GPL-2.0-or-later derivative of rbxport. Upstream source,
attribution and license remain included.

Version 1.9.5 directly embeds the copied CueIt core, superseding the independent
phrase detector as the active playlist preparation path. See the
[CueIt integration and scope](beatwarrior-cueit.md). The 1.9.4 description below
records the earlier local implementation and research, not the active engine.

## Three-screen workflow

1. Choose a folder and select music files. Only the checked files are imported.
2. Preparation starts automatically: native analysis, strictly ascending BPM
   with harmonic ordering within exact tempo ties, and phrase-based cues. Completion advances
   directly to the final screen.
3. Name the playlist and choose **Maak playlist**. It appears in the normal
   rbxport library with the prepared order and cues.

The app opens directly in the library/player workspace. A persistent brand
navigation bar contains Library & players, **+ Playlist maken**, USB export
and Settings. The playlist maker is an inline workspace, with no modal or
splash screen. USB export and settings also render inside the main window.
The underlying library/player components remain mounted while navigating. There are no cue inputs, review checkboxes, genre controls, pair controls or
USB settings in this workflow. USB export remains available through the normal
Beatwarrior USB-export workspace.

Named cues are sent in one native batch per track. The encrypted library is
opened once per batch and the cue index refreshed on the same connection,
instead of reopening for each cue and each comment. Progress identifies the
check, cue and playlist phases. Errors retain their diagnostic message and
restore the save button. Mutating calls are not raced against fake timeouts.
The native fixture test writes 36 markers and a 12-track playlist, reopens
the database and verifies membership and existing-cue preservation.

## Ascending BPM and whole-track phrase phase in 1.9.4

Automatic order is now monotonically nondecreasing in the stored BPM. Key cannot
cause a downward tempo step. Exact BPM ties use harmonic proximity; unknown BPM
tracks stay at the end. The planner cannot fill an unavoidable gap when no
intermediate-tempo song was selected; such transitions remain advisory warnings.

The native full-file spectral pass also returns twelve log-band descriptors per
stored bar, reusing the already-computed FFT frames. The local TypeScript phrase
planner combines those with bar energy and drum occupancy. Self-similarity
contrast across four/eight-bar windows scores structural changes over the whole
track. Structural peaks and labelled sections vote for an eight-bar phrase
phase, including pickup offsets. One local kick entrance cannot alone become A
on the third/fourth bar of that phase. All generated A/B/C cues lie on its
boundaries; B-to-C and incoming A-to-drop use equal integer bar counts.
An invalid pair uses a whole-phrase fallback, rather than clipping to one bar.

This is an independently implemented regular-dance phrase lattice inspired by
barwise similarity research, not a CBM reproduction or a trained neural model.
It assumes predominantly eight-bar organisation; unusual inserted bars and
changing phrase lengths still need listening checks. Low phase separation is
reported as a warning, never as a guarantee of semantic intro/drop correctness.
No music uploads, external service, model downloads or Python runtime are used.
See [research notes](beatwarrior-phrase-research.md) for reviewed implementations,
specific differences and acceptance limits.

## Non-blocking automatic playlists in 1.9.3

Transition confidence is advisory. All successfully imported tracks remain in
one ordered playlist, including tracks whose cue analysis fails. Known tempos
are ordered strictly ascending in 1.9.4; unknown tempos are
retained at the end. Invalid pair alignment uses a bounded stored-bar overlap
where possible. It never invents an off-grid cue timestamp.

The playlist and ordered membership are saved before cue updates. Each track's
cue write is checked independently; invalid/stale grids, unavailable analysis,
personal occupied pads or a failed cue batch leave that track's existing cues
intact and do not undo the playlist or stop later cue updates. The completion
screen reports transition cautions and the number of unchanged cue sets.
Actual library-write failures remain errors. Native write protection applies.
Regression tests include 78 tracks with 12 transition warnings, cue-write
failure continuation and a selection whose entire cue analysis fails.

## Reversible context-menu cleanup in 1.9.2

Both library playlists (including intelligent playlists) and individual library
track rows have **Verwijder alle hot cues, memory cues en loops** in their
right-click menus. The per-track action uses the row under the pointer, not the
selection. Missing-audio library tracks are supported; loose Explorer files
and device-only rows do not accidentally become library edits.

Normal playlists resolve membership inside one database transaction, including
members outside the current search/page and deduplicating repeated membership.
Intelligent playlists resolve the full unfiltered index view in bounded pages,
then pass its captured track IDs to one atomic clear. The writer validates all
IDs before any cue update. It only tombstones currently live cue rows; audio,
analysis, playlist membership and ordering remain unchanged. The same tracks
in other playlists lose the same shared cues. USBs require re-export.

Each operation is one ordinary session undo entry (Ctrl+Z), with exact row IDs
retained. Undo restores original positions, names, colours and loop out-points,
and never resurrects older tombstones. A newly occupied hot-cue pad blocks
restore atomically instead of overwriting a later cue. New cue edits invalidate
the redo branch. Both native write guards and frontend Library Protection apply.
User library writes were not used for verification: native fixtures cover hot,
memory and loop rows, shared/duplicate memberships, non-target preservation,
undo/redo, injected SQL failure, restore conflicts and invalid/empty scopes.
Browser/mock tests check menu availability and the clicked-row target.

## A/B/C preparation in 1.9.1

A is the earliest sustained rhythmic entry, B starts the next track at its A,
and C is the outgoing handover aligned with the next track's intro end/drop.
They are written to actual hot-cue pads A, B and C, with no pad reassignment,
fourth DROP pad or memory fallback. Known legacy Beatwarrior labels are replaced
atomically per track, including old DROP cues. Personal cues remain untouched;
a personal cue occupying A/B/C refuses preparation before any cue write.

The stored grid is checked against full-file spectral structure (12 bands,
multiscale novelty, half-beat and bar-phase scoring), even on an analysed track.
A separated structural phase can correct a half-beat shift or wrong downbeat
numbering through the ordinary native grid editor. The corrected result is
rechecked; locked grids are not bypassed. The phase score is a heuristic margin,
not a calibrated probability. Values below 0.06 and recordings over 20 minutes
are refused by this automatic path instead of receiving guessed cues.

Bar-synchronous audio measurements identify the earliest sustained drum entry,
a first labelled/structurally supported bass return and a labelled outro or a
complete phrase before the rhythmic tail. A is never selected by counting back
from the largest later drop. Local attack thresholds avoid discarding a quiet
intro solely because a later drop is louder. Unlabelled phrase lengths and
intro ends remain estimates; there is no vocal isolation or universal guarantee
of musically correct segmentation. An off-grid phrase label is rejected as an
anchor, rather than copied directly into a cue.

B is derived from integer bar indices, without an off-grid seconds fallback.
Every A/B/C is checked within 1 ms of a stored downbeat both before writing and
after validating the current grid. Unmatched intro/drop alignment, unstable
outgoing rhythms, variable tempo, excessive BPM steps and incompatible keys
produce advisory transition warnings in 1.9.3. Tracks whose analysis fails stay
in the playlist with their existing cues preserved.
The final playlist still requires equal playback tempo for the planned alignment;
this program does not render an audio mix or automate the DJ's faders.

## Open-source reference review

No external implementation or trained weights were copied into this fork.
The following were reviewed as design references:

- [Mixxx silence analyser](https://github.com/mixxxdj/mixxx/blob/main/src/analyzer/analyzersilence.cpp)
  distinguishes audible boundaries from musical intro/outro sections (0.001
  magnitude silence floor). [AutoDJ](https://github.com/mixxxdj/mixxx/blob/main/src/library/autodj/autodjprocessor.cpp)
  aligns incoming and outgoing sections, rather than arbitrary seconds.
- [Alalu DJ planner](https://github.com/Prahas10/audio-engine/blob/main/core/planner.py)
  distinguishes phrase candidate selection, local intro/downbeat selection and
  final beat alignment. This motivated keeping those validation stages separate.
- [madmom downbeat tracking](https://github.com/CPJKU/madmom/blob/main/madmom/features/downbeats.py)
  explicitly tracks beat position within a bar: a BPM or detected pulse is not
  itself proof of bar-one. Its neural models are not bundled or used here.

Beatwarrior uses its existing rbxport structural DSP and a new local cue planner.
Ground-truth synthetic fixtures cover offset starts, 128/150/180/200 BPM, later
stronger drops, off-grid labels, beat-two rejection and grid renumbering. Native
tests cover actual pad kinds/timestamps, legacy migration, personal-cue
preservation and transaction rollback. The user's real selection has not been
supplied for listening/annotation-based acceptance.

The existing export engine writes Device Library and OneLibrary. CDJ-3000 and
XDJ-RX2 are hardware acceptance targets, not physical-player test claims.

## Build and verification

Windows prerequisites: Rust, MSVC C++ build tools, Windows SDK, WebView2, Perl.
Use the installed dependencies and `Build-Beatwarrior.ps1` to create the NSIS
installer with the Beatwarrior identity and icons. Official updater endpoints
are disabled for this derivative.

The wizard, automatic playlist orchestration, cue preservation and cancellation
are covered by frontend tests. The native generated-fixture export test passed
for cue/grid/companion files and both library formats; it does not establish
physical-player playback. Use isolated fixtures for write tests, never the
user's installed music library.

## Retained feature areas

The existing library engine and player components have not been replaced.
The integrated library retains explorer/import, playlists and smart lists,
search/filter/sort, metadata, history, tag lists, player layouts, waveforms,
cue/loop/grid editors, audio controls and LINK. The USB workspace retains
iTunes import, device management, library export, sync preferences and import
preferences. Settings retain analysis, audio, view, keyboard, DJ-system and
advanced/backup controls. Automated tests and mock-browser navigation are
checks of these software paths, not a claim that every physical device or
Windows audio configuration has been exercised.
