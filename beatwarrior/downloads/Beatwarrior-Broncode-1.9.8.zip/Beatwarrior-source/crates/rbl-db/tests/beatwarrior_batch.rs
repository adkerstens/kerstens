//! Beatwarrior writes against an isolated schema fixture, never user music.
#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
use rbl_db::{fixture::{self,Shape,track_id},write::Writer};

#[test]
fn named_batches_create_a_real_playlist_and_keep_existing_cues() {
    let dir=tempfile::tempdir().unwrap();
    let location=fixture::build(dir.path(),Shape::default()).unwrap();
    let mut writer=Writer::open(location.clone(),dir.path().join("backups")).unwrap();
    writer.disable_automatic_backups();
    let first=track_id(0);
    let existing=writer.add_cue(&first,1,100).unwrap();
    let tracks:Vec<String>=(0..12).map(track_id).collect();
    for track in &tracks {
        let ids=writer.add_named_cues(track,&[(0,0,"Beatwarrior START".into()),(0,60000,"Beatwarrior DROP".into()),(0,180000,"Beatwarrior OVERNAME / UIT".into())]).unwrap();
        assert_eq!(ids.len(),3);
    }
    let playlist=writer.create_playlist("Beatwarrior regression","root").unwrap();
    writer.add_tracks(&playlist,&tracks).unwrap();
    let db=writer.library().connection();
    let count:i64=db.query_row("SELECT COUNT(*) FROM djmdSongPlaylist WHERE PlaylistID=?1 AND rb_local_deleted=0",[&playlist],|r|r.get(0)).unwrap();
    assert_eq!(count,12);
    let count:i64=db.query_row("SELECT COUNT(*) FROM djmdCue WHERE Comment LIKE 'Beatwarrior %' AND rb_local_deleted=0",[],|r|r.get(0)).unwrap();
    assert_eq!(count,36);
    assert!(writer.cue_owner(&existing).unwrap().is_some());
    assert!(writer.add_named_cues(&first,&[(1,200,"must refuse".into())]).is_err());
    assert!(writer.cue_owner(&existing).unwrap().is_some());
    drop(writer);
    let reopened=rbl_db::Library::open(location,rbl_db::OpenMode::ReadOnly).unwrap();
    let count:i64=reopened.connection().query_row("SELECT COUNT(*) FROM djmdSongPlaylist WHERE PlaylistID=?1 AND rb_local_deleted=0",[&playlist],|r|r.get(0)).unwrap();
    assert_eq!(count,12);
}

#[test]
fn abc_replaces_old_planner_markers_but_preserves_personal_cues_atomically() {
    let dir=tempfile::tempdir().unwrap();let location=fixture::build(dir.path(),Shape::default()).unwrap();
    let mut writer=Writer::open(location,dir.path().join("backup")).unwrap();writer.disable_automatic_backups();
    let track=track_id(0);
    let old=writer.add_cue(&track,1,12345).unwrap();writer.set_cue_comment(&old,"Beatwarrior START").unwrap();
    let old_drop=writer.add_cue(&track,5,67890).unwrap();writer.set_cue_comment(&old_drop,"Beatwarrior DROP").unwrap();
    let personal=writer.add_cue(&track,6,999).unwrap();writer.set_cue_comment(&personal,"My own E cue").unwrap();
    let markers=vec![(1,0,"Beatwarrior A - INSTART".into()),(2,180000,"Beatwarrior B - VOLGENDE START".into()),(3,240000,"Beatwarrior C - UITMIX".into())];
    let ids=writer.replace_beatwarrior_cues(&track,&markers).unwrap();assert_eq!(ids.len(),3);
    assert!(writer.cue_owner(&old).unwrap().is_none());assert!(writer.cue_owner(&old_drop).unwrap().is_none());
    assert!(writer.cue_owner(&personal).unwrap().is_some());
    let stored:Vec<(u8,u32,String)>={let mut stmt=writer.library().connection().prepare("SELECT Kind,InMsec,Comment FROM djmdCue WHERE ContentID=?1 AND Kind BETWEEN 1 AND 3 AND rb_local_deleted=0 ORDER BY Kind").unwrap();let rows=stmt.query_map([&track],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))).unwrap();rows.collect::<rusqlite::Result<_>>().unwrap()};
    assert_eq!(stored,markers);
    let repeat=writer.replace_beatwarrior_cues(&track,&markers).unwrap();assert_eq!(repeat.len(),3);
    let db=writer.library().connection();let count:i64=db.query_row("SELECT COUNT(*) FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0",[&track],|r|r.get(0)).unwrap();assert_eq!(count,4);
    let other=track_id(1);let user=writer.add_cue(&other,2,3000).unwrap();writer.set_cue_comment(&user,"User B").unwrap();
    assert!(writer.replace_beatwarrior_cues(&other,&markers).is_err());
    let count:i64=writer.library().connection().query_row("SELECT COUNT(*) FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0",[&other],|r|r.get(0)).unwrap();assert_eq!(count,1);
}

#[test]
fn abc_replacement_rolls_back_on_a_database_failure() {
    let dir=tempfile::tempdir().unwrap();let location=fixture::build(dir.path(),Shape::default()).unwrap();
    let mut writer=Writer::open(location,dir.path().join("backup")).unwrap();writer.disable_automatic_backups();let track=track_id(0);
    let old=writer.add_cue(&track,1,12345).unwrap();writer.set_cue_comment(&old,"Beatwarrior START").unwrap();
    writer.library().connection().execute_batch("CREATE TRIGGER fail_b BEFORE INSERT ON djmdCue WHEN NEW.Kind=2 BEGIN SELECT RAISE(FAIL,'fixture write error');END;").unwrap();
    let markers=vec![(1,0,"Beatwarrior A - INSTART".into()),(2,180000,"Beatwarrior B - VOLGENDE START".into()),(3,240000,"Beatwarrior C - UITMIX".into())];
    assert!(writer.replace_beatwarrior_cues(&track,&markers).is_err());assert!(writer.cue_owner(&old).unwrap().is_some());
    let count:i64=writer.library().connection().query_row("SELECT COUNT(*) FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0",[&track],|r|r.get(0)).unwrap();assert_eq!(count,1);
}

#[test]
fn automatic_playlist_persists_234_cues_for_78_tracks_and_replaces_occupied_pads() {
    let dir=tempfile::tempdir().unwrap();let location=fixture::build(dir.path(),Shape{tracks:78,..Shape::default()}).unwrap();
    let mut writer=Writer::open(location.clone(),dir.path().join("backup")).unwrap();writer.disable_automatic_backups();
    let tracks:Vec<String>=(0..78).map(track_id).collect();
    for track in tracks.iter().take(55) {writer.add_cue(track,1,123).unwrap();writer.add_loop(track,2,3000,6000,4).unwrap();}
    let keep=writer.add_cue(&tracks[0],6,999).unwrap();let memory=writer.add_loop(&tracks[0],0,4000,8000,8).unwrap();
    let playlist=writer.create_playlist("New Rave","root").unwrap();writer.add_tracks(&playlist,&tracks).unwrap();
    let markers=vec![(1,0,"Beatwarrior A - INSTART".into()),(2,180000,"Beatwarrior B - VOLGENDE START".into()),(3,240000,"Beatwarrior C - UITMIX".into())];
    for track in &tracks {
        assert_eq!(writer.replace_playlist_abc_cues(track,&markers).unwrap().len(),3);
        let stored:Vec<(u8,u32,String)>={let mut stmt=writer.library().connection().prepare("SELECT Kind,InMsec,Comment FROM djmdCue WHERE ContentID=?1 AND Kind BETWEEN 1 AND 3 AND rb_local_deleted=0 ORDER BY Kind").unwrap();let rows=stmt.query_map([track],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))).unwrap();rows.collect::<rusqlite::Result<_>>().unwrap()};
        assert_eq!(stored,markers);
    }
    writer.replace_playlist_abc_cues(&tracks[0],&markers).unwrap();
    assert!(writer.cue_owner(&keep).unwrap().is_some());assert!(writer.cue_owner(&memory).unwrap().is_some());
    drop(writer);
    let db=rbl_db::Library::open(location,rbl_db::OpenMode::ReadOnly).unwrap();
    let count:i64=db.connection().query_row("SELECT COUNT(*) FROM djmdCue WHERE Kind BETWEEN 1 AND 3 AND rb_local_deleted=0",[],|r|r.get(0)).unwrap();assert_eq!(count,234);
    let members:i64=db.connection().query_row("SELECT COUNT(*) FROM djmdSongPlaylist WHERE PlaylistID=?1 AND rb_local_deleted=0",[&playlist],|r|r.get(0)).unwrap();assert_eq!(members,78);
}

#[test]
fn automatic_replacement_is_atomic_even_for_preexisting_personal_pads() {
    let dir=tempfile::tempdir().unwrap();let location=fixture::build(dir.path(),Shape::default()).unwrap();
    let mut writer=Writer::open(location,dir.path().join("backup")).unwrap();writer.disable_automatic_backups();let track=track_id(0);
    let old=writer.add_cue(&track,1,12345).unwrap();writer.set_cue_comment(&old,"Personal A").unwrap();
    writer.library().connection().execute_batch("CREATE TRIGGER fail_automatic_b BEFORE INSERT ON djmdCue WHEN NEW.Kind=2 BEGIN SELECT RAISE(FAIL,'fixture write failure');END;").unwrap();
    let markers=vec![(1,0,"Beatwarrior A - INSTART".into()),(2,180000,"Beatwarrior B - VOLGENDE START".into()),(3,240000,"Beatwarrior C - UITMIX".into())];
    assert!(writer.replace_playlist_abc_cues(&track,&markers).is_err());assert!(writer.cue_owner(&old).unwrap().is_some());
    let count:i64=writer.library().connection().query_row("SELECT COUNT(*) FROM djmdCue WHERE ContentID=?1 AND rb_local_deleted=0",[&track],|r|r.get(0)).unwrap();assert_eq!(count,1);
}
